These protos are the Boston Dynamics Public API.


