"""Module for LeaseService clients."""

import bosdyn.api.lease_service_pb2 as lease_protos
import bosdyn.api.lease_service_pb2_grpc as lease_service


class Error(Exception):
    """Generic base class for all exceptions thrown from the lease_client module."""
    pass


class CachedLeaseExists(Error):
    """A cached lease already exists."""
    pass


class CachedLeaseMissing(Error):
    """A cached lease is missing."""
    pass


class LeaseClient(object):
    """LeaseClient is a client for a single LeaseService instance.

    The LeaseClient maintains a local cache of leases for resources. If the
    local cache is not sufficient to satisfy a response, RPC calls will be
    issued to the service.
    """

    def __init__(self, channel, request_header_generator,
                 add_lease_callback=None, remove_lease_callback=None):
        """Creates a new LeaseClient object.

        Arguments:
            * channel: A grpc.Channel object which acts as the communication
              channel to a single LeaseService instance.
            * request_header_generator: A bosdyn.client.processors.AddRequestHeader
              object which populates the common RequestHeader message in every
              RPC.
            * add_lease_callback: Callback which is invoked whenever a lease
              is added to the local cache. Expected to be a callable which takes
              a Lease argument.
            * remove_lease_callback: Callback which is invoked whenver a lease
              is removed from the local cache. Expected to be a callable which
              takes a Lease argument.
        """
        self._channel = channel
        self._stub = lease_service.LeaseServiceStub(channel)
        self._request_header_generator = request_header_generator

        def nil_lease_callback(lease):
            pass
        self._add_lease_callback = add_lease_callback or nil_lease_callback
        self._remove_lease_callback = remove_lease_callback or nil_lease_callback
        self._lease_cache = {}

    def _add_lease_to_cache(self, lease):
        self._lease_cache[lease.resource] = lease
        self._add_lease_callback(lease)

    def _remove_lease_from_cache(self, lease):
        del self._lease_cache[lease.resource]
        self._remove_lease_callback(lease)

    def acquire_lease(self, resource):
        """Acquire a lease for a resource.

        If a cached lease already exists for the resource, a CachedLeaseExists
        exception is raised and nothing else happens. Otherwise, an
        AcquireLease RPC is issued. If the RPC is successful, the returned lease
        is stored in the local cache.

        Arguments:
           * resource: The name of the resource to acquire a lease for.

        Returns:
           * The AcquireLeaseResponse message received over RPC.

        Raises:
           * CachedLeaseExists if a locally cached lease exists.
        """
        if resource in self._lease_cache:
            raise CachedLeaseExists()
        request = lease_protos.AcquireLeaseRequest()
        self._request_header_generator.add_header(request)
        request.resource = resource
        response = self._stub.AcquireLease(request)
        if response.status == lease_protos.AcquireLeaseResponse.STATUS_OK:
            self._add_lease_to_cache(response.lease)
        return response

    def take_lease(self, resource):
        """Take a lease for a resource.

        If a cached lease already exists for the resource, a CachedLeaseExists
        exception is raised and nothing else happens. Otherwise, a
        TakeLease RPC is issued. If the RPC is successful, the returned lease
        is stored in the local cache.

        Arguments:
           * resource: The name of the resource to acquire a lease for.

        Returns:
           * The TakeLeaseResponse message received over RPC.

        Raises:
           * CachedLeaseExists if a locally cached lease exists.
        """
        if resource in self._lease_cache:
            raise CachedLeaseExists()
        request = lease_protos.AcquireLeaseRequest()
        self._request_header_generator.add_header(request)
        request.resource = resource
        response = self._stub.TakeLease(request)
        if response.status == lease_protos.TakeLeaseResponse.STATUS_OK:
            self._add_lease_to_cache(response.lease)
        return response

    def return_lease(self, resource):
        """Return a lease for a resource.

        If no cached lease exists for the resource, a CachedLeaseMissing
        exception is raised and nothing else happens. Otherwise, a
        ReturnLease RPC is issued. If the response shows that the service
        no longer considers the cached lease to be the active lease,
        remove the cached representation.

        Arguments:
           * resource: The name of the resource to acquire a lease for.

        Returns:
           * The ReturnLeaseResponse message received over RPC.

        Raises:
           * CachedLeaseMissing if a locally cached lease exists.
        """
        if resource not in self._lease_cache:
            raise CachedLeaseMissing()
        request = lease_protos.ReturnLeaseRequest()
        self._request_header_generator.add_header(request)
        request.lease.CopyFrom(self._lease_cache[resource])
        response = self._stub.ReturnLease(request)
        if response.status in [lease_protos.ReturnLeaseResponse.STATUS_OK,
                               lease_protos.ReturnLeaseResponse.STATUS_INVALID_RESOURCE,
                               lease_protos.ReturnLeaseResponse.STATUS_NOT_ACTIVE_LEASE]:
            self._remove_lease_from_cache(request.lease)
        return response

    def list_resources(self):
        """List resources being managed by the LeaseService.

        Returns:
           * The ListLeaseResourcesResponse message received.
        """
        request = lease_protos.ListLeasesRequest()
        self._request_header_generator.add_header(request)
        response = self._stub.ListLeases(request)
        return response

    def retain_lease(self, lease):
        """ Retain possession of a lease. """
        request = lease_protos.RetainLeaseRequest(lease=lease)
        self._request_header_generator.add_header(request)
        response = self._stub.RetainLease(request)
        return response

    def get_cached_lease(self, resource):
        """Returns the locally cached lease for resource if one exists.

        Arguments:
            * resource: The name of the resource to find a lease for.

        Returns:
            * The Lease message if a cached lease exists, or None otherwise.
        """
        return self._lease_cache.get(resource, None)

    def remove_cached_lease(self, resource):
        """Removes the locally cached lease for a resource if one exists.

        remove_cached_lease does not return the lease to the LeaseService.

        Arguments:
            * resource: The name of the resource to remove a locally cached
              lease for.
        """
        if resource not in self._lease_cache:
            return
        lease = self._lease_cache[resource]
        self._remove_lease_from_cache(lease)
