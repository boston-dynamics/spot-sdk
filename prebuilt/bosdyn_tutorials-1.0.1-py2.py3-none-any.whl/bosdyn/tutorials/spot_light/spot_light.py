"""
Tutorial to demonstrate how to use the API to create a custom user interface

This script will allow spot to response to a light shining in its front
left camera.  The following describes what to expect:

  - with the robot sitting, shine a light into the front left camera, spot should stand up
  - shine a light into the front left camera again, spot should start following the light
  - remove the light, spot should sit down

NOTE: Both the light detection and controller is very crude.  One needs to have a very steady
hands and prevent the robot from "seeing" other bright light in the front left camera.

To run this, do:
python spot_light.py <robot_name>

Dependencies:
cv2
numpy
simple_pid
"""

import sys

import bosdyn.client
import bosdyn.client.util

from MySpot import MySpot
from StateMachine import StateMachine
from StateMachine import StateMachineSit
from StateMachine import StateMachineStand
from StateMachine import StateMachineFollow

#===================================================================================================
# Local Helpers

def _parse_arguments(argv):
    """
    This function defines the arguments used for this module.

    @param[in]  argv  The argument string to parse
    """
    import argparse
    parser = argparse.ArgumentParser(description='Spot API Test')
    bosdyn.client.util.add_common_arguments(parser)
    options = parser.parse_args(argv)
    return options

#===================================================================================================
# Main entry

def main(argv):

    # Parse arguments given
    options = _parse_arguments(argv)
    try:
        # Create spot
        my_spot = MySpot()
        my_spot.connect(options)

        # Create the state machines
        spot_states = [StateMachineSit(my_spot), StateMachineStand(my_spot), StateMachineFollow(my_spot)]
        # Enter the sit state by default
        spot_states[0].enable = True
        # From the sit state, it will transition to stand if light is seen
        spot_states[0].next_state = spot_states[1]
        # From stand, it will transition to follow if light is seen
        spot_states[1].next_state = spot_states[2]
        # From follow, it will transition back to sit if light is not seen
        spot_states[2].next_state = spot_states[0]

        # Start the state machine
        while True:
            for state in spot_states:
                state.exe()

    except Exception as exc:
        print("Spot threw an exception: {}".format(exc))
        return False
    except KeyboardInterrupt:
        pass

    print("Done!!")

if __name__ == '__main__':
    if not main(sys.argv[1:]):
        sys.exit(1)
